/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class PaqueteTuristico {

    public PaqueteTuristico() {
        this.alojamiento = "";
        this.traslados = "";
        this.excusiones = "";
        this.alimentacion = "";
        this.precio = 0;
    }
    public PaqueteTuristico(String alojamiento, String traslados, String excusiones, String alimentacion, int precio) {
        this.alojamiento = alojamiento;
        this.traslados = traslados;
        this.excusiones = excusiones;
        this.alimentacion = alimentacion;
        this.precio = precio;
    }
    
    private String alojamiento;
    private String traslados;
    private String excusiones;
    private String alimentacion;
    private int precio;
    public ArrayList<AgenciaViaje> tieneAgenciaViaje= new ArrayList();
    public GestionReserva tieneGestionReserva ;
   
    public String getAlojamiento() {
        return alojamiento;
    }

    public void setAlojamiento(String alojamiento) {
        this.alojamiento = alojamiento;
    }

    public String getTraslados() {
        return traslados;
    }

    public void setTraslados(String traslados) {
        this.traslados = traslados;
    }

    public String getExcusiones() {
        return excusiones;
    }

    public void setExcusiones(String excusiones) {
        this.excusiones = excusiones;
    }

    public String getAlimentacion() {
        return alimentacion;
    }

    public void setAlimentacion(String alimentacion) {
        this.alimentacion = alimentacion;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
    public String Publicidad()
    {  
       return "No esta implementado este metodo";
    }   
}
