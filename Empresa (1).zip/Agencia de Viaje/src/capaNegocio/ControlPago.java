/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class ControlPago {

    public ControlPago() {
    }

    public ControlPago(String efectivo, String Transferencia, String credito, String cuotas) {
        this.efectivo = efectivo;
        this.Transferencia = Transferencia;
        this.credito = credito;
        this.cuotas = cuotas;
    }
    
    private String efectivo;
    private String Transferencia;
    private String credito;
    private String cuotas;
    public ArrayList<AgenciaViaje> perteneceAgenciaViaje= new ArrayList();
    public GestionReserva tieneGestionReserva ;

    public String getEfectivo() {
        return efectivo;
    }

    public void setEfectivo(String efectivo) {
        this.efectivo = efectivo;
    }

    public String getTransferencia() {
        return Transferencia;
    }

    public void setTransferencia(String Transferencia) {
        this.Transferencia = Transferencia;
    }

    public String getCredito() {
        return credito;
    }

    public void setCredito(String credito) {
        this.credito = credito;
    }

    public String getCuotas() {
        return cuotas;
    }

    public void setCuotas(String cuotas) {
        this.cuotas = cuotas;
    }
            
}
