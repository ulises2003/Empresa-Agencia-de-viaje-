/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

/**
 *
 * @author Usuario
 */
public class Proveedor {

    public Proveedor() {
    }

    public Proveedor(String nombreEmpresa, String direccion, String ruc) {
        this.nombreEmpresa = nombreEmpresa;
        this.direccion = direccion;
        this.ruc = ruc;
    }
    
    private String nombreEmpresa;
    private String direccion;
    private String ruc;
    public AgeciaViaje  tieneAgeciaViaje ;

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getRuc() {
        return ruc;
    }

    public void setRuc(String ruc) {
        this.ruc = ruc;
    }
    public String Distribuir()
    {  
       return "No esta implementado este metodo";
    }  
    public String Vender()
    {  
       return "No esta implementado este metodo";
    }   
    
}
