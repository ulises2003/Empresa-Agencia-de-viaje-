/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package capaNegocio;

import java.util.Date;

/**
 *
 * @author Usuario
 */
public class GestionReserva {

    public GestionReserva() {
        this.fechaReserva = null;
        this.nombreReserva = "";
        this.adelantoReserva = 0;
    }

    public GestionReserva(Date fechaReserva, String nombreReserva, int adelantoReserva) {
        this.fechaReserva = fechaReserva;
        this.nombreReserva = nombreReserva;
        this.adelantoReserva = adelantoReserva;
    }
    
    
    private Date fechaReserva;
    private String nombreReserva;
    private int adelantoReserva;
    public GestionReserva tieneGestionReserva ;
    public ControlPago tieneControlPago;

    public Date getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(Date fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

    public String getNombreReserva() {
        return nombreReserva;
    }

    public void setNombreReserva(String nombreReserva) {
        this.nombreReserva = nombreReserva;
    }

    public int getAdelantoReserva() {
        return adelantoReserva;
    }

    public void setAdelantoReserva(int adelantoReserva) {
        this.adelantoReserva = adelantoReserva;
    }
    
            
}
